const Discord = require("discord.js");
module.exports = {
   name: "uptime",
   description: "Check Discord Bot Uptime!",
   run: async (client, inter, config, db) => {
      const { default: msImported } = await import("parse-ms");
      let time = msImported(client.uptime);

      let embed = new Discord.MessageEmbed()
         .setThumbnail(inter.guild.iconURL())
         .setColor(0xff0033)
         .setTitle(`${config.emoji || ":skull:"} | Uptime`)
         .setDescription(
            `${time.days} days, ${time.hours} hours, ${time.minutes} minutes, ${time.seconds} seconds`,
         )
         .setFooter("Created By Roomy12#9873");

      inter.reply({ embeds: [embed], ephemeral: true });
   },
};
